<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Connected Center — Login</title>
<script src="../theme-sync.js"></script>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body, input, button, label {
    font-family: 'Avenir Next Regular', 'Avenir Next', 'Avenir', sans-serif;
    font-weight: 400;
  }
  h1, h2, strong { font-family: 'Avenir Next Medium', 'Avenir Next', 'Avenir', sans-serif !important; font-weight: 500 !important; }
  body {
    min-height: 100vh;
    background: var(--theme-bg, #f0f4f9);
    display: flex; align-items: center; justify-content: center;
    color: var(--theme-text-primary, #1a1a2e);
    padding: 24px 16px;
  }
  .blur-bg { position: fixed; z-index: 0; inset: 0; pointer-events: none; overflow: hidden; }
  .blur-ball { position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0; mix-blend-mode: lighten; animation: ballFloat 18s ease-in-out infinite alternate, ballIn 1.2s cubic-bezier(.4,0,.2,1) forwards; }
  .bb1 { width: 420px; height: 420px; background: var(--theme-ball-1, rgba(130,180,255,0.5)); left: -80px; top: -60px; animation-delay: 0s, 0.1s; }
  .bb2 { width: 340px; height: 340px; background: var(--theme-ball-2, rgba(200,160,255,0.45)); right: -60px; top: 10vh; animation-delay: 3s, 0.3s; }
  .bb3 { width: 280px; height: 280px; background: var(--theme-ball-3, rgba(130,230,200,0.4)); left: 20vw; bottom: 5vh; animation-delay: 6s, 0.5s; }
  @keyframes ballFloat { 0% { transform: translateY(0); } 100% { transform: translateY(-28px); } }
  @keyframes ballIn { 0% { opacity: 0; } 100% { opacity: 0.55; } }
  @keyframes cardIn { from { opacity:0; transform: translateY(24px) scale(0.96); } to { opacity:1; transform: none; } }
  @keyframes riseIn { from { opacity:0; transform: translateY(14px); } to { opacity:1; transform: none; } }
  @keyframes iconFloat { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
  @keyframes pulseRing {
    0% { transform: scale(0.9); opacity: 0.5; }
    70% { transform: scale(1.35); opacity: 0; }
    100% { opacity: 0; }
  }

  .card {
    position: relative; z-index: 1;
    width: 440px; max-width: calc(100vw - 32px);
    background: var(--theme-glass-tint, rgba(255,255,255,0.72));
    border: 1px solid var(--theme-glass-border, rgba(255,255,255,0.7));
    border-radius: 28px;
    padding: 36px 34px 32px;
    backdrop-filter: blur(28px) saturate(180%);
    -webkit-backdrop-filter: blur(28px) saturate(180%);
    box-shadow: 0 16px 56px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.6);
    animation: cardIn 0.5s cubic-bezier(0.22,1,0.36,1);
  }

  .gate { text-align: center; margin-bottom: 22px; }
  .gate-icon-wrap {
    position: relative;
    width: 76px; height: 76px;
    margin: 0 auto 18px;
    animation: riseIn 0.55s cubic-bezier(0.22,1,0.36,1) both;
  }
  .gate-icon-wrap::before {
    content: '';
    position: absolute; inset: -8px;
    border-radius: 26px;
    border: 2px solid var(--theme-accent, #2196f3);
    animation: pulseRing 2.4s ease-out infinite;
  }
  .gate-icon {
    width: 76px; height: 76px; border-radius: 22px;
    background: linear-gradient(145deg, var(--theme-accent, #2196f3), #6366f1);
    display: flex; align-items: center; justify-content: center;
    font-size: 34px;
    box-shadow: 0 12px 32px rgba(33,150,243,0.35);
    animation: iconFloat 4s ease-in-out infinite;
    position: relative; z-index: 1;
  }
  .gate h1 {
    font-size: clamp(1.35rem, 4vw, 1.65rem);
    color: var(--theme-text-primary, #1a1a2e);
    line-height: 1.25;
    letter-spacing: -0.02em;
    margin: 0 0 10px;
    animation: riseIn 0.55s 0.08s cubic-bezier(0.22,1,0.36,1) both;
  }
  .gate .subtitle {
    color: var(--theme-text-secondary, #666);
    font-size: 0.98rem;
    line-height: 1.5;
    max-width: 32ch;
    margin: 0 auto;
    animation: riseIn 0.55s 0.14s cubic-bezier(0.22,1,0.36,1) both;
  }

  .form-block {
    animation: riseIn 0.55s 0.2s cubic-bezier(0.22,1,0.36,1) both;
  }

  .msg { padding: 10px 14px; border-radius: 12px; font-size: 13px; margin-bottom: 14px; }
  .msg-err  { background: rgba(229,57,53,0.1); color: #c62828; }
  .msg-info { background: rgba(33,150,243,0.1); color: #1565c0; }

  label { display: block; font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.7px; color: var(--theme-text-secondary, #888); margin-bottom: 6px; margin-top: 14px; }
  input {
    width: 100%;
    background: rgba(255,255,255,0.65);
    border: 1px solid var(--theme-glass-border, rgba(0,0,0,0.12));
    border-radius: 12px; color: var(--theme-text-primary, #1a1a2e);
    font-family: inherit; font-size: 14px;
    padding: 12px 14px; outline: none;
    transition: border-color 0.15s, box-shadow 0.15s, transform 0.15s;
  }
  input:focus {
    border-color: var(--theme-accent, #2196f3);
    box-shadow: 0 0 0 3px rgba(33,150,243,0.14);
    transform: translateY(-1px);
  }

  .btn {
    width: 100%; background: var(--theme-accent, #2196f3); color: #fff;
    border: none; border-radius: 14px;
    padding: 14px; font-family: inherit; font-size: 15px; font-weight: 600;
    cursor: pointer; margin-top: 20px;
    transition: filter 0.15s, transform 0.1s, box-shadow 0.2s;
    box-shadow: 0 8px 24px rgba(33,150,243,0.32);
  }
  .btn:hover { filter: brightness(1.08); box-shadow: 0 12px 28px rgba(33,150,243,0.4); }
  .btn:active { transform: scale(0.98); }

  .divider { height: 1px; background: var(--theme-glass-border, rgba(0,0,0,0.08)); margin: 22px 0; }
  .footer-links { text-align: center; font-size: 13px; color: var(--theme-text-secondary, #888); }
  .footer-links a { color: var(--theme-accent, #2196f3); text-decoration: none; font-weight: 600; }
  .footer-links a:hover { text-decoration: underline; }

  body.embed-mode { min-height: 100%; padding: 12px; }
  body.embed-mode .card { width: 100%; max-width: none; padding: 12px 14px 16px; box-shadow: none; border: none; background: transparent; backdrop-filter: none; -webkit-backdrop-filter: none; animation: none; }
  body.embed-mode .blur-bg { display: none; }
  body.embed-mode .gate { display: none; }
  body.embed-mode .form-block { animation: none; }
  body.embed-mode label:first-of-type { margin-top: 0; }
  body.embed-mode .btn { margin-top: 16px; padding: 12px; }
</style>
</head>
<body>
<div class="blur-bg">
  <div class="blur-ball bb1"></div>
  <div class="blur-ball bb2"></div>
  <div class="blur-ball bb3"></div>
</div>
<div class="card">
  <div class="gate">
    <div class="gate-icon-wrap">
      <div class="gate-icon" aria-hidden="true">💬</div>
    </div>
    <h1>You're not signed in to Connected Center</h1>
    <p class="subtitle">And it's not the same without you. Sign-in to make the most of Nexus</p>
  </div>

  <div class="form-block">
        
    <form method="POST" autocomplete="on">
            <label>Username or Email</label>
      <input type="text" name="identifier" placeholder="your_username" autocomplete="username" required />
      <label>Password</label>
      <input type="password" name="password" placeholder="••••••••" autocomplete="current-password" required />
      <button class="btn" type="submit">Sign In</button>
    </form>

    <div class="divider"></div>
    <div class="footer-links">
      Don't have an account? <a href="signup.php">Create one</a>
    </div>
  </div>
</div>
</body>
</html>
